// Функция за превключване на темата
function invertColors() {
 document.querySelector('footer').classList.toggle('invert-footer');
 document.querySelector('header').classList.toggle('invert-header');
 document.querySelector('body').classList.toggle('invert-body');
 // document.querySelector('.small-div').classList.toggle('inver-small-div');

 // Записване на предпочитаната тема в локалното съхранение
 const isDarkMode = document.body.classList.contains('invert-body');
 localStorage.setItem('darkMode', isDarkMode);
}

// Проверка при зареждане на страницата
document.addEventListener('DOMContentLoaded', function () {
 // Зареждане на предпочитаната тема от локалното съхранение
 const isDarkMode = localStorage.getItem('darkMode') === 'true';

 if (isDarkMode) {
     // Ако предпочитаната тема е тъмна, превключете към нея
     invertColors();
 }
});






// Функция за създаване на бисквитка
function setCookie(cname, cvalue, exdays) {
    const d = new Date();
    d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
    const expires = "expires=" + d.toUTCString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}

// Функция за прочитане на бисквитка
function getCookie(cname) {
    const name = cname + "=";
    const decodedCookie = decodeURIComponent(document.cookie);
    const ca = decodedCookie.split(';');
    for (let i = 0; i < ca.length; i++) {
        let c = ca[i];
        while (c.charAt(0) === ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) === 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}

// Функция за проверка на бисквитки и показване на банера
function checkCookieBanner() {
    const cookieAccepted = getCookie("cookieAccepted");
    if (cookieAccepted === "") {
        document.getElementById("cookie-banner").style.display = "flex";
    }
}

// Функция за скриване на банера и създаване на бисквитка
function acceptCookies() {
    document.getElementById("cookie-banner").style.display = "none";
    setCookie("cookieAccepted", "true", 365); // Бисквитката ще изтича след 365 дни
}

// Проверяваме бисквитката при зареждане на страницата
document.addEventListener("DOMContentLoaded", checkCookieBanner);

// Задаваме функцията за бутон "Приемам"
document.getElementById("accept-cookies").addEventListener("click", acceptCookies);