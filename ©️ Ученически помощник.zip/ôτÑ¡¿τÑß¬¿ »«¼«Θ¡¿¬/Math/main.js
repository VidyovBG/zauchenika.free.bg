






var input = document.getElementById('input'),
    result = document.getElementById('result'),
    inputType = document.getElementById('inputType'),
    resultType = document.getElementById('resultType'),
    inputTypeValue , resultTypeValue;

input.addEventListener('keyup' , myResult)
inputType.addEventListener('change' , myResult)
resultType.addEventListener('change' , myResult)

inputTypeValue = inputType.value
resultTypeValue = resultType.value

function myResult(){
    inputTypeValue = inputType.value
    resultTypeValue = resultType.value

    if(inputTypeValue === 'meter' && resultTypeValue === 'kilometer'){
        result.value = Number(input.value) * 0.001
    } else if(inputTypeValue === 'meter' && resultTypeValue === 'centimeter'){
        result.value = Number(input.value) * 100
    } else if(inputTypeValue === 'meter' && resultTypeValue === 'meter'){
        result.value = input.value
    } else if(inputTypeValue === 'meter' && resultTypeValue === 'decimeter'){
        result.value = Number(input.value) * 10
    } else if(inputTypeValue === 'meter' && resultTypeValue === 'milimeter'){
        result.value = Number(input.value) * 1000
    } else if(inputTypeValue === 'meter' && resultTypeValue === 'yard'){
        result.value = Number(input.value) * 1.09361
    } else if(inputTypeValue === 'meter' && resultTypeValue === 'mile'){
        result.value = Number(input.value) * 0.000621371
    } else if(inputTypeValue === 'meter' && resultTypeValue === 'inch'){
        result.value = Number(input.value) * 39.3701
    }

    if(inputTypeValue === 'kilometer' && resultTypeValue === 'meter'){
        result.value = Number(input.value) * 1000
    } else if(inputTypeValue === 'kilometer' && resultTypeValue === 'centimeter'){
        result.value = Number(input.value) * 100000
    } else if(inputTypeValue === 'kilometer' && resultTypeValue === 'kilometer'){
        result.value = input.value
    } else if(inputTypeValue === 'kilometer' && resultTypeValue === 'decimeter'){
        result.value = Number(input.value) * 10000
    } else if(inputTypeValue === 'kilometer' && resultTypeValue === 'milimeter'){
        result.value = Number(input.value) * 1000000
    } else if(inputTypeValue === 'kilometer' && resultTypeValue === 'yard'){
        result.value = Number(input.value) * 1093.61
    } else if(inputTypeValue === 'kilometer' && resultTypeValue === 'mile'){
        result.value = Number(input.value) * 0.621371
    } else if(inputTypeValue === 'kilometer' && resultTypeValue === 'inch'){
        result.value = Number(input.value) * 39370.1
    }

    if(inputTypeValue === 'centimeter' && resultTypeValue === 'kilometer'){
        result.value = Number(input.value) * 0.00001
    } else if(inputTypeValue === 'centimeter' && resultTypeValue === 'meter'){
        result.value = Number(input.value) * 0.01
    } else if(inputTypeValue === 'centimeter' && resultTypeValue === 'centimeter'){
        result.value = input.value
    } else if(inputTypeValue === 'centimeter' && resultTypeValue === 'decimeter'){
        result.value = Number(input.value) * 0.1
    } else if(inputTypeValue === 'centimeter' && resultTypeValue === 'milimeter'){
        result.value = Number(input.value) * 10
    } else if(inputTypeValue === 'centimeter' && resultTypeValue === 'yard'){
        result.value = Number(input.value) * 0.0109361
    } else if(inputTypeValue === 'centimeter' && resultTypeValue === 'mile'){
        result.value = Number(input.value) * 0.00001
    } else if(inputTypeValue === 'centimeter' && resultTypeValue === 'inch'){
        result.value = Number(input.value) * 0.3937
    }

    if(inputTypeValue === 'decimeter' && resultTypeValue === 'kilometer'){
        result.value = Number(input.value) *  0.0001
    } else if(inputTypeValue === 'decimeter' && resultTypeValue === 'meter'){
        result.value = Number(input.value) * 0.1
    } else if(inputTypeValue === 'decimeter' && resultTypeValue === 'decimeter'){
        result.value = input.value
    } else if(inputTypeValue === 'decimeter' && resultTypeValue === 'centimeter'){
        result.value = Number(input.value) * 10
    } else if(inputTypeValue === 'decimeter' && resultTypeValue === 'milimeter'){
        result.value = Number(input.value) * 100
    } else if(inputTypeValue === 'decimeter' && resultTypeValue === 'yard'){
        result.value = Number(input.value) * 0.109361
    } else if(inputTypeValue === 'decimeter' && resultTypeValue === 'mile'){
        result.value = Number(input.value) * 0.0000621371
    } else if(inputTypeValue === 'decimeter' && resultTypeValue === 'inch'){
        result.value = Number(input.value) * 3.93701
    }

    if(inputTypeValue === 'milimeter' && resultTypeValue === 'kilometer'){
        result.value = Number(input.value) * 0.000001
    } else if(inputTypeValue === 'milimeter' && resultTypeValue === 'meter'){
        result.value = Number(input.value) * 0.001
    } else if(inputTypeValue === 'milimeter' && resultTypeValue === 'decimeter'){
        result.value = Number(input.value) * 0.01
    } else if(inputTypeValue === 'milimeter' && resultTypeValue === 'centimeter'){
        result.value = Number(input.value) * 0.1
    } else if(inputTypeValue === 'milimeter' && resultTypeValue === 'milimeter'){
        result.value = input.value
    } else if(inputTypeValue === 'milimeter' && resultTypeValue === 'yard'){
        result.value = Number(input.value) * 0.00109361
    } else if(inputTypeValue === 'milimeter' && resultTypeValue === 'mile'){
        //result.value = Number(input.value) * 0.0000621371
        result.value = "-"
    } else if(inputTypeValue === 'milimeter' && resultTypeValue === 'inch'){
        result.value = Number(input.value) * 0.0393701
    }

    if(inputTypeValue === 'yard' && resultTypeValue === 'kilometer'){
        result.value = Number(input.value) * 0.0009144
    } else if(inputTypeValue === 'yard' && resultTypeValue === 'meter'){
        result.value = Number(input.value) * 0.9144
    } else if(inputTypeValue === 'yard' && resultTypeValue === 'decimeter'){
        result.value = Number(input.value) * 9.144
    } else if(inputTypeValue === 'yard' && resultTypeValue === 'centimeter'){
        result.value = Number(input.value) * 91.44
    } else if(inputTypeValue === 'yard' && resultTypeValue === 'milimeter'){
        result.value = Number(input.value) * 914.4
    } else if(inputTypeValue === 'yard' && resultTypeValue === 'yard'){
        result.value = input.value
    } else if(inputTypeValue === 'yard' && resultTypeValue === 'mile'){
        result.value = Number(input.value) * 0.000568182
    } else if(inputTypeValue === 'yard' && resultTypeValue === 'inch'){
        result.value = Number(input.value) * 36
    }

    if(inputTypeValue === 'mile' && resultTypeValue === 'kilometer'){
        result.value = Number(input.value) * 1.609344
    } else if(inputTypeValue === 'mile' && resultTypeValue === 'meter'){
        result.value = Number(input.value) * 11609.344
    } else if(inputTypeValue === 'mile' && resultTypeValue === 'decimeter'){
        result.value = Number(input.value) * 116093.44
    } else if(inputTypeValue === 'mile' && resultTypeValue === 'centimeter'){
        result.value = Number(input.value) * 1160934.4
    } else if(inputTypeValue === 'mile' && resultTypeValue === 'milimeter'){
        result.value = Number(input.value) * 11609344
    } else if(inputTypeValue === 'mile' && resultTypeValue === 'yard'){
        result.value = Number(input.value) * 1760
    } else if(inputTypeValue === 'mile' && resultTypeValue === 'mile'){
        result.value = input.value
    } else if(inputTypeValue === 'mile' && resultTypeValue === 'inch'){
        result.value = Number(input.value) * 63360
    }

    if(inputTypeValue === 'inch' && resultTypeValue === 'kilometer'){
        result.value = Number(input.value) * 0.0000254
    } else if(inputTypeValue === 'inch' && resultTypeValue === 'meter'){
        result.value = Number(input.value) * 0.0254
    } else if(inputTypeValue === 'inch' && resultTypeValue === 'decimeter'){
        result.value = Number(input.value) * 0.254
    } else if(inputTypeValue === 'inch' && resultTypeValue === 'centimeter'){
        result.value = Number(input.value) * 2.54
    } else if(inputTypeValue === 'inch' && resultTypeValue === 'milimeter'){
        result.value = Number(input.value) * 25.4
    } else if(inputTypeValue === 'inch' && resultTypeValue === 'yard'){
        result.value = Number(input.value) * 0.0277778
    } else if(inputTypeValue === 'inch' && resultTypeValue === 'mile'){
        result.value = Number(input.value) * 0.0000157828
    } else if(inputTypeValue === 'inch' && resultTypeValue === 'inch'){
        result.value = input.value
    }
}


function convertArea(value, fromUnit, toUnit) {
    const conversionFactors = {
        'meter2': 1,
        'kilometer2': 1e6,
        'centimeter2': 1e-4,
        'decimeter2': 1e-2,
        'milimeter2': 1e-6,
        'hectare2': 1e4,
        'dekar2': 1e2,
    };

    if (!conversionFactors.hasOwnProperty(fromUnit) || !conversionFactors.hasOwnProperty(toUnit)) {
        console.error('Невалидни квадратни мерни единици');
        return null;
    }

    const valueInSquareMeters = value * conversionFactors[fromUnit];
    const result = valueInSquareMeters / conversionFactors[toUnit];

    return result;
}

document.getElementById('input2').addEventListener('input', updateResult);

document.getElementById('inputType2').addEventListener('change', updateResult);

document.getElementById('resultType2').addEventListener('change', updateResult);

function updateResult() {
    const inputValue = parseFloat(document.getElementById('input2').value);
    const inputUnit = document.getElementById('inputType2').value;
    const resultUnit = document.getElementById('resultType2').value;

    const result = convertArea(inputValue, inputUnit, resultUnit);

    if (!isNaN(result)) {
        document.getElementById('result2').value = result;
    } else {
        document.getElementById('result2').value = '';
    }
}




function calculateStepen() {
    var baseElement = document.getElementById("stepenuvane1");
    var exponentElement = document.getElementById("stepenuvane2");
    var resultElement = document.getElementById("stepenuvane3");

    var base = parseFloat(baseElement.value);
    var exponent = parseInt(exponentElement.value);

    if (!isNaN(base) && !isNaN(exponent)) {
        if (base >= 0) {
            var result = Math.pow(base, exponent);
            resultElement.value = result;
        } else {
            resultElement.value = "";
            alert("Числото НЕ трябва да е отрицателно.");
            baseElement.value = ""; // Нулиране на стойността на input полето за числото
            exponentElement.value = ""; // Нулиране на стойността на input полето за степен
        }
    } else {
        resultElement.value = "";
        alert("Моля, въведете валидни числа за число и степен.");
    }
}
function calculateStepenNulirane() {
    var inputElement1 = document.getElementById("stepenuvane1");
    var inputElement2 = document.getElementById("stepenuvane2");
    var inputElement3 = document.getElementById("stepenuvane3");

    inputElement1.value = "";
    inputElement2.value = "";
    inputElement3.value = "";
}

function calculateRadikalNulirane() {
    var inputElement4 = document.getElementById("radikal1");
    var inputElement5 = document.getElementById("radikal2");

    inputElement4.value = "";
    inputElement5.value = "";
}

function calculatePermutaciqNulirane() {
    var inputElement6 = document.getElementById("fakturiel1");
    var inputElement7 = document.getElementById("fakturiel2");

    inputElement6.value = "";
    inputElement7.value = "";
}

inputElement.value = "";
function calculatePermutation() {
    var inputElement = document.getElementById("fakturiel1");
    var n = parseInt(inputElement.value);

    if (!isNaN(n) && n > 0) {
        var resultElement = document.getElementById("fakturiel2");
        var permutation = calculateFactorial(n);

        resultElement.value = permutation;
    } else {
        var resultElement = document.getElementById("fakturiel2");
        resultElement.value = "";
        alert("Моля, въведете положително число.");
        inputElement.value = ""; // Нулиране на стойността на input полето
    }
}

function calculateFactorial(n) {
    if (n === 0) {
        return 1;
    } else {
        return n * calculateFactorial(n - 1);
    }
}

// Функция за изчисляване на комбинация
function calculateKombinaciq() {
    // Вземане на стойностите на "n" и "k" от входните полета
    const n = parseInt(document.getElementById("kombinaciq1").value);
    const k = parseInt(document.getElementById("kombinaciq2").value);
  
    // Проверка дали n и k са по-големи или равни на 0
    if (n < 0 || k < 0) {
      alert("Моля, въведете положителни стойности за n и k.");
      // Нулиране на стойностите на трите input полета
      document.getElementById("kombinaciq1").value = "";
      document.getElementById("kombinaciq2").value = "";
      document.getElementById("kombinaciq3").value = "";
      return; // Излизаме от функцията при грешни стойности
    }

    if (k > n) {
      document.getElementById("kombinaciq3").value = "Грешка: k по-голямо от n";
      return;
    }

    // Изчисляване на комбинацията
    const kombinaciqResult = calculateCombination(n, k);
  
    // Показване на резултата в третото входно поле
    document.getElementById("kombinaciq3").value = kombinaciqResult;
  }
  
  // Функция за нулиране на полетата
  function calculateKombinaciqNulirane() {
    document.getElementById("kombinaciq1").value = "";
    document.getElementById("kombinaciq2").value = "";
    document.getElementById("kombinaciq3").value = "";
  }
  
  // Функция за изчисляване на комбинацията C(n, k)
  function calculateCombination(n, k) {
    function factorial(num) {
      if (num <= 1) return 1;
      return num * factorial(num - 1);
    }
  
    return factorial(n) / (factorial(k) * factorial(n - k));
  }
 


  
  function calculateVariation(n, k) {
    function factorial(num) {
        if (num <= 1) return 1;
        return num * factorial(num - 1);
    }
  
    return factorial(n) / factorial(n - k);
}

function calculateVariation(n, k) {
    function factorial(num) {
        if (num <= 1) return 1;
        return num * factorial(num - 1);
    }

    if (k > n) {
        return "Грешка: k по-голямо от n";
    }

    return factorial(n) / factorial(n - k);
}

function calculateVariaciq() {
    const n = parseInt(document.getElementById("variaciq1").value);
    const k = parseInt(document.getElementById("variaciq2").value);
    const resultContainer = document.getElementById("variaciq3");
  
    if (n < 0 || k < 0) {
        alert("Моля, въведете положителни стойности за n и k.");
        document.getElementById("variaciq1").value = "";
        document.getElementById("variaciq2").value = "";
        resultContainer.value = "";
        return;
    }

    const variaciqResult = calculateVariation(n, k);
  
    resultContainer.value = variaciqResult;
}

function calculateVariaciqNulirane() {
    document.getElementById("variaciq1").value = "";
    document.getElementById("variaciq2").value = "";
    document.getElementById("variaciq3").value = "";
}


function calculateKvUravnenie() {
    // Вземане на стойностите на "a", "b" и "c" от входните полета
    const a = parseFloat(document.getElementById("kvUravnenie1").value);
    const b = parseFloat(document.getElementById("kvUravnenie2").value);
    const c = parseFloat(document.getElementById("kvUravnenie3").value);

    // Изчисляване на дискриминантата (D)
    const D = b * b - 4 * a * c;

    // Проверка за стойността на дискриминантата
    if (D < 0) {
        // Ако D < 0, няма реални корени
        document.getElementById("kvUravnenie4").value = "Няма решение";
        document.getElementById("kvUravnenie5").value = "Няма решение";
    } else if (D === 0) {
        // Ако D = 0, имаме 1 реален корен
        const x1 = -b / (2 * a);
        document.getElementById("kvUravnenie4").value = `x1 = ${x1}`;
        document.getElementById("kvUravnenie5").value = "Няма втори корен";
    } else {
        // Ако D > 0, имаме 2 реални корена
        const x1 = (-b + Math.sqrt(D)) / (2 * a);
        const x2 = (-b - Math.sqrt(D)) / (2 * a);
        document.getElementById("kvUravnenie4").value = `x1 = ${x1}`;
        document.getElementById("kvUravnenie5").value = `x2 = ${x2}`;
    }
}

function calculateKvUravnenieNulirane() {
    document.getElementById("kvUravnenie1").value = "";
    document.getElementById("kvUravnenie2").value = "";
    document.getElementById("kvUravnenie3").value = "";
    document.getElementById("kvUravnenie4").value = "";
    document.getElementById("kvUravnenie5").value = "";
}


inputElement.value = "";
function calculateRoot() {
    var inputElement = document.getElementById("radikal1");
    var numberUnderRoot = parseFloat(inputElement.value);

    if (!isNaN(numberUnderRoot) && numberUnderRoot >= 0) {
        var resultElement = document.getElementById("radikal2");
        var simplifiedRoot = simplifyRoot(numberUnderRoot);

        resultElement.value = simplifiedRoot;
    } else {
        var resultElement = document.getElementById("radikal2");
        resultElement.value = "";
        alert("Моля, въведете валидно неотрицателно число под радикала.");
        inputElement.value = "";
    }
}

function simplifyRoot(number) {
    var sqrt = Math.sqrt(number);
    var largestSquare = 1;

    for (var divisor = 2; divisor <= sqrt; divisor++) {
        if (number % (divisor * divisor) === 0) {
            largestSquare = divisor * divisor;
        }
    }

    var simplifiedNumber = number / largestSquare;

    if (largestSquare === 1) {
        return "√" + simplifiedNumber;
    } else {
        return Math.sqrt(largestSquare) + "√" + simplifiedNumber;
    }
}



